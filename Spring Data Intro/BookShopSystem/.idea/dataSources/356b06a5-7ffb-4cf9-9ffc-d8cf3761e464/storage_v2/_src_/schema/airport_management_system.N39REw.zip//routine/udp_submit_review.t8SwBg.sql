create procedure udp_submit_review(IN customer_id  int, IN review_content varchar(255), IN review_grade int,
                                   IN airline_name varchar(30))
  BEGIN
	DECLARE review_id INT;
	DECLARE airline_id INT;
    
    SET review_id := (SELECT COUNT(*) + 1 FROM customer_reviews);
    SET airline_id := (SELECT airline_id FROM airlines
		WHERE airline_name = airline_name);
        
	START TRANSACTION;
    
     INSERT INTO customer_reviews(review_id,review_content,review_grade,
     airline_id,customer_id)
     VALUES (review_id,review_content,
     review_grade,airline_id,customer_id);
     
     IF(airline_name IN(SELECT a.airline_name FROM airlines a))THEN
       SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'The issue does not exist!';
        ROLLBACK;
     END IF;
     COMMIT;
END;

