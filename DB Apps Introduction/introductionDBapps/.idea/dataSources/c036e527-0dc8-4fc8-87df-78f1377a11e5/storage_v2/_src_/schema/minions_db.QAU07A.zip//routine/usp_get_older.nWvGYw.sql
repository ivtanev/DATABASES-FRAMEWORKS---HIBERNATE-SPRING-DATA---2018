create procedure usp_get_older(IN id int)
  (
    SELECT name,age FROM minions WHERE minions.id = id
);

