package alararestaurant.service;

import org.springframework.stereotype.Service;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Override
    public String exportCategoriesByCountOfItems() {
        // TODO : Implement me
        return null;
    }
}
